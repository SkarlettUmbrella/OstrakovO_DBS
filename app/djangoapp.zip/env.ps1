$Env:DBHOST = "localhost"
$Env:DBUSER = "manager"
$Env:DBNAME = "pollsdb"
$Env:DBPASS = "supersecretpass"
